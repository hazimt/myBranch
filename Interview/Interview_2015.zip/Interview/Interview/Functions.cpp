#include "stdafx.h"
#include <stdio.h>

//#include "interview.cpp"

int test()
{
	printf("\n");
	printf("hello from function.");
	printf("\n");
	return 0;
}

