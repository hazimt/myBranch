#pragma once

class Element
{
public:
	Element(void);
public:
	~Element(void);
};
