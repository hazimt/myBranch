#include "stdafx.h"
#include "Element.h"

Element::Element(void)
{
}

Element::~Element(void)
{
}
