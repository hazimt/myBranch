﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Access_Private_Member
{
    class Program
    {
        static void Main(string[] args)
        {
            ExampleOne one = new ExampleOne();

            TamilValga.ExampleTwo two = new TamilValga.ExampleTwo();

            Tamil three = new Tamil();
            MessageBox.Show("Acess the private member by methods \n" + three.AccessPriveMemberMessage("தமிழ் வாழ்க! தமிழ் வளர்க!!"));

         }
    }


    public class Tamil
    {
        private string message = "தமிழ் வாழ்க!";

        public  string AccessPriveMemberMessage(string value)
        {
            message = value;
            return message;
        }
    }

    public class ExampleOne : Tamil
    {
        public ExampleOne()
        {
            System.Reflection.FieldInfo receivedObject = typeof(Tamil).GetFields(System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)[0];
            var obj = receivedObject.GetValue(this);
            MessageBox.Show("Access the private member using Reflection \n "+obj.ToString());
        }
    }

    public class TamilValga
    {
        private string message = "தமிழ் வாழ்க!";
        public class ExampleTwo : TamilValga
        {
            public ExampleTwo()
            {
                MessageBox.Show("Access the private member using base by sub class \n " + base.message);
            }
        }

    }

}
